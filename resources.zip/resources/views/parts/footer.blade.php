<footer class="container-fluid footer">
    <div class="container text-center">
        <div class="footer-logo"><img src="{{ asset('assets/images/footerlogo.png') }}" style="height: 85px" alt="Footer Logo"></div>
        <p class="laread-motto">AK Web Developer</p>
        <div class="laread-social">
            <a href="#" class="fa fa-twitter"></a>
            <a href="#" class="fa fa-facebook"></a>
            <a href="#" class="fa fa-pinterest"></a>
        </div>
    </div>
</footer>